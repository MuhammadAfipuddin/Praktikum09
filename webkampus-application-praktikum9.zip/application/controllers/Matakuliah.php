<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {
	public function index(){
        $this->load->model('matakuliah_model', 'matkul1');
        $this->matkul1->nama = 'Pemrograman Web';
        $this->matkul1->sks = '4';
        $this->matkul1->kode = "111";

        $this->load->model('matakuliah_model', 'matkul2');
        $this->matkul2->nama = 'Basis Data';
        $this->matkul2->sks = '4';
        $this->matkul2->kode = "222";

        $this->load->model('matakuliah_model', 'matkul3');
        $this->matkul3->nama = 'Pendidikan Agama Islam';
        $this->matkul3->sks = '2';
        $this->matkul3->kode = "333";

        $list_matkul = [$this->matkul1, $this->matkul2, $this->matkul3];

        $data['matakuliah1'] = $this->matkul1;
        $data['list_matakuliah'] = $list_matkul;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');

        $this->load->view('matakuliah/index', $data);

        $this->load->view('layout/footer');
    }

    public function create(){
        $data ['judul'] = 'Form Kelola Matakuliah';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('matakuliah/create', $data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model('matakuliah_model', 'matkul4');

        $this->matkul4->nama = $this->input->post('nama');
        $this->matkul4->sks = $this->input->post('sks');
        $this->matkul4->kode = $this->input->post('kode');

        $data['matkul4'] = $this->matkul4;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('matakuliah/view', $data);
        $this->load->view('layout/footer');
    }
}

